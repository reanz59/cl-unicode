The files in this directory were downloaded from

  http://unicode.org/Public/UNIDATA/

on 2018-01-01.

The file DerivedCoreProperties.txt is only used for testing.
